/* tslint:disable */
require("./AtlasFlipsterConnect.module.css");
const styles = {
  atlasFlipsterConnect: 'atlasFlipsterConnect_ce93293e',
  containter21: 'containter21_ce93293e',
  textontheimage1: 'textontheimage1_ce93293e',
  button: 'button_ce93293e',
  ImageClass: 'ImageClass_ce93293e',
  ImageContainer: 'ImageContainer_ce93293e',
  ImageClass1: 'ImageClass1_ce93293e',
  textontheimage: 'textontheimage_ce93293e',
  container: 'container_ce93293e',
  flip: 'flip_ce93293e',
  show: 'show_ce93293e'
};

export default styles;
/* tslint:enable */