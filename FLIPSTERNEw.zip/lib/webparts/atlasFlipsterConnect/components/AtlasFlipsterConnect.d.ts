import * as React from 'react';
import { IAtlasFlipsterConnectProps } from './IAtlasFlipsterConnectProps';
import 'jquery.flipster/dist/jquery.flipster.min.css';
import "jquery.flipster/dist/jquery.flipster.min.js";
import "jquery.flipster/dist/jquery.flipster.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import "jquery.flipster";
import "bootstrap";
export interface IAtlasFlipsterConnectState {
    parentItems: any;
    childItems: any;
    displayFlag: any;
    displayLoader: any;
}
export default class AtlasFlipsterConnect extends React.Component<IAtlasFlipsterConnectProps, IAtlasFlipsterConnectState> {
    private SPService;
    constructor(props: any);
    componentDidMount(): void;
    jQueryFlipsterFunction(): void;
    getParentItems(): Promise<void>;
    getChild(linkID: string, linkName: string, counter: number): Promise<void>;
    render(): React.ReactElement<IAtlasFlipsterConnectProps>;
}
//# sourceMappingURL=AtlasFlipsterConnect.d.ts.map