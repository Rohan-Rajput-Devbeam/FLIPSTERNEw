import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IAtlasFlipsterConnectProps {
    description: string;
    context: WebPartContext;
    Category: string;
}
//# sourceMappingURL=IAtlasFlipsterConnectProps.d.ts.map