import { WebPartContext } from "@microsoft/sp-webpart-base";
import "@pnp/sp/webs";
import "@pnp/sp/folders";
export declare class SPService {
    private context;
    state: {
        allItems: any[];
        currPageUrl: string;
        currUserGroups: any[];
    };
    abc: any[];
    rackName: string;
    people: [];
    authuser: boolean;
    constructor(context: WebPartContext);
    getUserGroups(): Promise<any>;
    getAllDocs(): Promise<any>;
    getparentBrand(categoryName: any): Promise<any[]>;
    getChildBrands(parentLinkID: string): Promise<any[]>;
}
//# sourceMappingURL=SPServices.d.ts.map