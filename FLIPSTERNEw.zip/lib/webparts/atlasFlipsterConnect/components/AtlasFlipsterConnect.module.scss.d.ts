declare const styles: {
    atlasFlipsterConnect: string;
    containter21: string;
    textontheimage1: string;
    button: string;
    ImageClass: string;
    ImageContainer: string;
    ImageClass1: string;
    textontheimage: string;
    container: string;
    flip: string;
    show: string;
};
export default styles;
//# sourceMappingURL=AtlasFlipsterConnect.module.scss.d.ts.map