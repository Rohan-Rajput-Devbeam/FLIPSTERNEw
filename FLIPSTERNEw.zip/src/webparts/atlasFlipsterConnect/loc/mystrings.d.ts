declare interface IAtlasFlipsterConnectWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AtlasFlipsterConnectWebPartStrings' {
  const strings: IAtlasFlipsterConnectWebPartStrings;
  export = strings;
}
