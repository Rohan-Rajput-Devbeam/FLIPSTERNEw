import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IAtlasFlipsterConnectWebPartProps {
    description: string;
    Category: string;
}
export default class AtlasFlipsterConnectWebPart extends BaseClientSideWebPart<IAtlasFlipsterConnectWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=AtlasFlipsterConnectWebPart.d.ts.map